##############################################################################################
#											    
#		MAP COMPARISON TOOL					     
#											    
# 	This R script compares two ascii maps in terms of accuracy.			     
# 	Calculations: 									    
# 		- Confusion matrix (integers & proportions), kappa, weighted kappa 	     
# 		  and CII for all the categories present in ascii maps.			    
# 		- AUC, omission rates, sensitivity, specificity				     
#       and proportion of correct instances, for each category independently	    
#											    
# 	Required packages: maptools, clv, psych						     
#											     
# 	Author: Alicia Garcia-Arias (Universitat Politecnica de Valencia - GIMHA)	     
# 	Date: August 2011								     
# 	e-mail: algarar2@posgrado.upv.es						     
#											     
##############################################################################################



#################################################################
#	         	 Initial setup				
#################################################################

options("warn"=-1) # suppress warnings
rm(list=ls()) # remove all the variables
library(maptools)
library(clv)
library(psych)


#################################################################
#	          MODIFY ONLY THIS SETTINGS			
#################################################################

DataPath <- "C:/R/demo/"  # Use this data path structure on windows (The example path is a folder called 'R' and sited in the C: hard drive)
#DataPath <- "/home/ali/R/"   Use this data path structure on linux
ObsMapFilename <- "obsmap_demo.asc" # observed categories map (NoData values must be correctly defined in the ascii map file)
SimMapFilename <- "simmap_demo.asc" # simulated categories map (NoData values must be correctly defined in the ascii map file)
ResultsFilename <- "results_demo.txt" # output file

categories <- c(101,102,201,202,203,301) # Different possible categories ordered
thresholds <- c(0.9, 0.8, 0.9, 0.9, 0.9, 1) # This vector includes the specific thresholds required to determine which likelihood predicted value will be consider a success (based on expert knowledge). The vector must have as much elements as different phases. The thresholds must be between 0 and 1. 

N <- length(categories) # calculates the number of categories defined
WeightedKappa <- 0 # Set this value to 1 if you want to use specific weights based on expert knowledge
weights <- matrix(c(1, 0.8, 0, 0, 0, 0,
		                0.8, 1, 0.6, 0, 0, 0,
		                0, 0.6, 1, 0.9, 0.4, 0,
		                0, 0, 0.9, 1, 0.7, 0,
		                0, 0, 0, 0.7, 1, 0,
		                0, 0, 0, 0, 0, 1),ncol=N)   ##### Considering the number of categories (N), the dimensions of this matrix must be NxN. The matrix structure matches with the confusion matrix structure.

#################################################################################################
#												
# 					IMPORTANT!						
# FROM NOW ON IT IS NOT RECOMMENDABLE TO MODIFY THE SCRIPT UNLESS YOU KNOW WHAT YOU ARE DOING	
#												
#################################################################################################


#################################################################
#	 Load the maps as vectors removing NoData values 	
#################################################################

obsfname <- paste(DataPath,ObsMapFilename,sep="")
simfname <- paste(DataPath,SimMapFilename,sep="")
resfname <- paste(DataPath,ResultsFilename,sep="")

obs_prev <- data.frame (readAsciiGrid (obsfname))
sim_prev <- data.frame (readAsciiGrid (simfname))

x <-obs_prev[,1] # We only need the first column of values, the coordinates are noise data
y <-sim_prev[,1]

for (r in c(1:N)) { x[x==categories[r]]=r ; y[y==categories[r]]=r }

#################################################################
#			Input checks				
#################################################################

if (length(x)!=length(y)) stop('ERROR: your input maps have not the same number of observed & predicted values')
if (length(thresholds)!=N) stop('ERROR: you have introduced a wrong number of thresholds')
	


#################################################################
#		 Calculate the confusion matrix		 	
#################################################################

mat_e <- confusion.matrix(x,y) # the confusion matrix in integer terms
n <- sum(mat_e) # mumber of elements
mat_p <- mat_e/n # the confusion matrix in proportion terms
cat("\n","Confusion matrix (Integers)","\n")
write.table(mat_e, append=T, col.names = categories, row.names = categories) 
cat("\n","Confusion matrix (Proportions)","\n")
write.table(mat_p, append=T, col.names = categories, row.names = categories)
cat("\n","N = ",n,"\n","\n")

#################################################################
#	     Calculate kappa and weighted kappa		 	
#################################################################

kappa <- wkappa(mat_p)
print(kappa) 	

#################################################################
#	Calculate weighted kappa with specific weights		
#################################################################

if (WeightedKappa == 1) {
	kappa2 <- wkappa(mat_p,weights)	
	print(kappa2[2])
}

#################################################################
#	Calculate Correctly Clasified instances (CCI)		
#################################################################

CCI <- sum(diag(mat_p))
cat("Correctly Classified instances (CCI) = ",CCI,"\n","\n") 	

#################################################################
#    Print results (the file will be overwritten if exists)
#################################################################

cat("Confusion matrix (Integers)","\n","\n",file=resfname)
write.table(mat_e, file=resfname, append=T, col.names = categories, row.names = categories) ### cols and rows names can be defined as vectors
cat("\n","\n","Confusion matrix (Proportions)","\n","\n",file=resfname, append=T)
write.table(mat_p, file=resfname, append=T, col.names = categories, row.names = categories)
cat("\n","\n","number of simulated points = ",n,"\n","\n","Correctly Clasified instances (CCI) = ",CCI,"\n","\n","Kappa: ","\n", file=resfname, append=T)
lapply(kappa[1], write, file=resfname, append=T)
cat("Weighted kappa (default weights):","\n", file=resfname, append=T)
lapply(kappa[2], write, file=resfname, append=T)
if (WeightedKappa == 1) {
	cat("\n","\n","Weighted kappa with specific weights:","\n", file=resfname, append=T)
	lapply(kappa2[2], write, file=resfname, append=T)
}
cat("\n","\n",file=resfname, append=T)

#################################################################
#		  AUC function definition			
#################################################################

aucfunc <- function(obs,pred){
	#input checks
	if (length(obs)!=length(pred)) stop('this requires the same number of observed & predicted values')
	
	
	#deal with NAs
	if (length(which(is.na(c(obs,pred))))>0) {
		na = union(which(is.na(obs)),which(is.na(pred)))
		warning(length(na),' data points removed due to missing data')
		obs = obs[-na]; pred = pred[-na]
	}

	#define the n's and do checks
	n = length(obs); if (length(which(obs %in% c(0,1)))!=n) stop('observed values must be 0 or 1') #ensure observed are values 0 or 1
	n1 = length(which(obs==1)); n0 = length(which(obs==0))
	if (n1==0 || n1==n) return( NaN ) #if all observed 1's or 0's return NaN

	###calc AUC
	pred0 = pred[which(obs==0)]
	pred1 = pred[which(obs==1)]
	ranks = rank(pred,ties.method='average')#define ranks
	ranks0 = ranks[which(obs==0)]
	ranks1 = ranks[which(obs==1)]
	U = as.double(n0)*as.double(n1) + (n0*(n0+1))/2 - sum(ranks0) #calc U stat
	AUC = U/(as.double(n0)*as.double(n1)) #estimate AUC
	if (AUC<.5) AUC = 1-AUC
	
	#return the auc value
	return(AUC)
}

########################### Calculate accuracy ##################################
#										
# 	For these calculations a mask (values 0 or 1) is defined 		
# 	considering absence/presence of each category in the ObsMap.		
# 	The SimMap categories are converted to likelihood values 		
# 	(from 0 to 1) by comparison with the ObsMap categories. The		
# 	equation employed for likelihood calculation is 1-|obs-sim|/N		
#										
#################################################################################

for (z in c(1:N)) {  # this loop is defined for 10 phases, if there are only 6 you should put c(1:6)
	checkvalue<-length(x[which(x==z)])
	if (checkvalue==0) { 
		cat("\n******* The phase number",z,"is not present in 'ObsMap'******* \n \n",file=resfname, append=T)
		next 
        }
        else {	
		mask <- x
		mask[which(mask!=z)] = 0
		mask[which(mask==z)] = 1
		threshold <- thresholds[z]
		likelihood <- ifelse(x > y, 1-(x-y)/max(x), 1-(y-x)/max(x))
		likelihood[which(likelihood>=threshold)] = 1; likelihood[which(likelihood<threshold)] = 0
	
		mat <- table (mask,likelihood) # Considering number of: true positives (TP), true negatives (TN), false positives (FP) and false negatives (FN)
		auc <- aucfunc(mask,likelihood)
		omission <- (mat[2,1]/sum(mat[,1])) # = FN/(TN+FN)
		commission <- (mat[1,2]/sum(mat[,2])) # = FP/(FP+TP)
		sensitivity <- (mat[2,2]/sum(mat[2,])) # = TP/(TP+FN)
		specificity <- (mat[1,1]/sum(mat[1,])) # = TN/(TN+FP)
		propcorrect <- (sum(diag(mat))/sum(mat))# = (TN+TP)/(TN+TP+FN+FP)

    cat("\n","Accuracy results for phase = ",categories[z],"\n","\n","Presence/absence confusion matrix:","\n","\n")
		write.table(mat, col.names = c("absence","presence"), row.names = c("absence","presence"))
 	  cat("\n","AUC = ",auc,"\n","omission =",omission,"\n","commission =",commission,"\n", "sensitivity = ",sensitivity,"\n","specificity = ",specificity,"\n","prop.correct = ",propcorrect,"\n","\n")

		cat("\n","Accuracy results for phase = ",categories[z],"\n","\n","Presence/absence confusion matrix:","\n","\n",file=resfname,append=T)
		write.table(mat, file=resfname, append=T, col.names = c("absence","presence"), row.names = c("absence","presence"))
    cat("\n","AUC = ",auc,"\n","omission =",omission,"\n","commission =",commission,"\n", "sensitivity = ",sensitivity,"\n","specificity = ",specificity,"\n","prop.correct = ",propcorrect,"\n","\n",file=resfname, append=T)

	}
}

#################################################################
#	       Print a successfully ended message		
#################################################################

print("Ended successfully. Check the results file.")



