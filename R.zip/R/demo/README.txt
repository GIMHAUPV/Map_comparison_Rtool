##############################################################################################
##############################################################################################
#											    
#		MAP COMPARISON TOOL					     
#											    
# 	This R script compares two ascii maps in terms of accuracy.			     
# 	Calculations: 									    
# 		- Confusion matrix (integers & proportions), kappa, weighted kappa 	     
# 		  and CII for all the categories present in ascii maps.			    
# 		- AUC, omission and commission rates, sensitivity, specificity				     
#       and proportion of correct instances, for each category independently	    
#											    
# 	Required packages: maptools, clv, psych						     
#											     
# 	Author: Alicia Garcia-Arias (Universitat Politecnica de Valencia - GIMHA)	     
# 	Date: August 2011								     
# 	e-mail: algarar2@posgrado.upv.es						     
#											     
##############################################################################################
##############################################################################################
	


USER GUIDE:


	1.	Download and install R: http://cran.r-project.org/bin/windows/base/R-2.14.0-win.exe
		Download and install Tinn-R: http://downloads.sourceforge.net/project/tinn-r/Tinn-R%20setup/2.3.7.1/Tinn-R_2.3.7.1_setup.exe?r=http%3A%2F%2Fsourceforge.net%2Fprojects%2Ftinn-r%2F&ts=1321531435&use_mirror=switch

	2. 	Copy the R folder in C:/ (If you don't have a hard drive named C:, copy the folder in other path and go to section 3, where the way to modify the path in the script is explained

	3. 	Open the script MapCompTool.R in Tinn-R. Modify only the contents between lines from 37 to 57

		- line 37 : DataPath <- "C:/R/demo/" Use this data path structure (The example path is a folder called 'demo' inside 'R' and sited in the C: hard drive)

		- line 39: ObsMapFilename <- "obsmap_demo.asc" Name of the first map to be compared, in example: ObsMapFilename <- "map1_test001.asc".

		- line 40: SimMapFilename <- "simmap_demo.asc" Name of the second map to be compared, in example: SimMapFilename <- "map2_test001.asc"

		############################################################################################################################################################################################		

		NOTE: Both maps must be in the folder specified in the DataPath. 
		      The number of cells with data values must be equal in both maps. Otherwise R will show an error message.

		############################################################################################################################################################################################		

		- line 41: ResultsFilename <- "results_demo.txt"  Results file name (it must be *.txt), in example: "results_test001.txt"

		############################################################################################################################################################################################				

		NOTA: The results file will be saved in the folder specified in the DataPath. 
		      If the file already exists it will be overwritten. 

		############################################################################################################################################################################################		

		- line 43: categories <- c(101,102,201,202,203,301) Categor�es present in the maps ordered by affinity. In the demo are 6 categor�es. Only integers are accepted as categories.

		- line 44: thresholds <- c(0.9, 0.8, 0.9, 0.9, 0.9, 1) Thresholdsd to consider agreement in the indices calculation (AUC, Senstivity, specificity, omission and commission rates and ACC. 
			                                               The thresholds are expert rules and in the script are expected to be calculated as follows:
									List the categories starting on 1; in the demo 101 would be the category number 1, 102 the number 2, 201 the number 3....
									Now, considering N as the number of categories, the likelihood calculation is 1-|obs-sim|/N. In example:
									If simulated values of 101 and 201 should be considered as agreement when 102 is observed:
         						                     � For 201:   1-|obs-sim|/N =  1 - |2-3|/10   =  1 - 0.1 = 0.9
						                             � For 101:   1-|obs-sim|/N =  1 - |2-1|/10   =  1 - 0.1 = 0.9
									The threshold for 102 is 0.9.
									In the demo, the last category corresponds to 301 and has been assigned a threshold = 1, this implies that only simulated values of 301 will be considered as correct answers.
									If no thresholds want to be considered, establish values=1 for all the categories.

		############################################################################################################################################################################################				

		NOTE: All the thresholds must be numbers between 0 and 1.

		############################################################################################################################################################################################				

		- line 46: N <- length(categories)  Do not modify this line. The script calculates automatically N, which will be from now on the number of categories. In the demo N=6

		- line 47: WeightedKappa <- 1  If you don't want to use it, change the 1 with a 0. The script calculates by default the coeficient of agreement weighted kappa (Cohen, 1968). In this case the weights on the diagonal are 1 and the weights off the
					       diagonal are reduced by the squared distance from the diagonal.
					       If we maintain activated this option (WeightedKappa <- 1), an additional weighted kappa value will be calculated with the weights established in the weights matrix (line 48).

		- line 48: weights <- matrix(c(  1, 0.8,   0,   0,   0, 0,
		               			0.8,   1, 0.6,   0,   0, 0,
		               			  0, 0.6,   1, 0.9, 0.4, 0,
		                                  0,   0, 0.9,   1, 0.7, 0,
		                                  0,   0,   0, 0.7,   1, 0,
		                                  0,   0,   0,   0,   0, 1),ncol=N) Weights matrix for the second weighted kappa calculation. 

		############################################################################################################################################################################################				

		NOTA: The matrix must be square (NxN) and in the main diagonal values must be = 1. The weights in the remaining positions will be numbers between 0 and 1.
		      If the WeightedKappa calculation is activated (line 47), the result of this calculation will be shown the second one. The first one corresponds to the default weighted kappa 
		      calculation, in which the weights are reduced considering the squared distance from the diagonal.

		############################################################################################################################################################################################				


	4. Save the changes made in the script.

	5. Run R.
		In the top menu go to Packages>Install package(s), and install the following packages: 'maptools', 'clv' and 'psych'. This has to be done only the first time.
		In the top menu go to File > Source R code and search the script MapCompTool.R
	   	Open it and, once the script has been run, the results can be seen both in the R console and in the results file.
	
           #################################################################################################################################################################################################				

    	   NOTE: In the R console, when the "up arrow" key is pressed, the last written instruction is recalled. 

           #################################################################################################################################################################################################			

	